package com.example.pokemonspeedtest;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class pokemonAdapter extends RecyclerView.Adapter {

    ArrayList<pokemon> pArray;
    Context context;

    public pokemonAdapter(ArrayList<pokemon> pArray, Context context) {
        this.pArray = pArray;
        this.context = context;

    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.layout, parent, false);
        Viewholder vh = new Viewholder((v));
        return vh;
    }


    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {
        ((Viewholder) holder).ing.setImageResource(pArray.get(position).getImage());
        ((Viewholder) holder).total.setText(pArray.get(position).getTotal() + "");
        ((Viewholder) holder).name.setText(pArray.get(position).getName());
        ((Viewholder) holder).view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, MainActivity2.class);
                i.putExtra("pokemon", pArray.get(position));

                context.startActivity(i);


            }
        });
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        ((Viewholder) holder).delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                builder.setTitle("DELETE");
                builder.setMessage("are you sure you want to free this pokemon");
                builder.setCancelable(false).setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        pArray.remove(position);
                        notifyDataSetChanged();

                    }

                }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();


            }
        });

    }


    @Override
    public int getItemCount() {
        return pArray.size();
    }


    public static class Viewholder extends RecyclerView.ViewHolder {
        public ImageView ing;
        public TextView name;
        public TextView total;
        public View view;
        public ImageView delete;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            ing = itemView.findViewById(R.id.imageView2);
            name = itemView.findViewById(R.id.name);
            total = itemView.findViewById(R.id.total2);
            delete = itemView.findViewById(R.id.delete);
        }
    }
}


